class SelectedList {
  final String id;
  final String name;

  SelectedList({required this.id, required this.name});
}
